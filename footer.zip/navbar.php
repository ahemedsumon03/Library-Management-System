  		
	<?php include('tooltip.php'); ?>			
	<div class="navbar navbar-fixed-top navbar-inverse">
            <div class="navbar-inner">
                <div class="container">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </a>
                    <div class="nav-collapse collapse">
					<ul class="nav">
					<li class=""><a  rel="tooltip"  data-placement="bottom" title="Home" id="home"   href="index.php">&nbsp;Home</a> </li>
					
					<!--<li class="">
					<a rel="tooltip"  data-placement="bottom" title="Click Here to About" id="login" href="about.php">&nbsp;About</a> 
					</li> -->
					<li class="">
					<a rel="tooltip"  data-placement="bottom" title="Click Here to About" id="login" href="librarian">&nbsp;Librarian</a>
					</li>
					<li class="">
					<a rel="tooltip"  data-placement="bottom" title="Click Here to About" id="login" href="about.php">&nbsp;Contact</a> 
					</li>
					
					
					<li class="signup"><span class="sg"></span></li>
					</ul>

			

                    
						

                    </div>
                </div>
            </div>
        </div>
   

	     	