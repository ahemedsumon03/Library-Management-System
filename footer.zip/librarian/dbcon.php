<?php
mysql_select_db('LibraryManagementSystem',mysql_connect('localhost','root',''))or die(mysql_error());
?>