					<li>		
					<a href="borrow.php"  data-toggle="dropdown" >dealings</a>
					<ul class="dropdown-menu">
					<li><a href="borrow.php">&nbsp;Loan</a></li>					
					<li><a href="view_borrow.php">&nbsp;Show Loaned Books</a></li>
					<li><a href="return.php">&nbsp;Show Returned Books</a></li>
					</ul>
					</li>