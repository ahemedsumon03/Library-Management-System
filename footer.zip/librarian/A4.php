<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
	<?php include('header.php'); ?>
<?php include('navbar.php'); ?>
	<div class="container" style="text-align:center;margin-top:55px;">
	
	<img src="http://localhost/images/A4.jpg" alt="" />
	<h3>Coding All-in-One For Dummies  <br /></h3>
	<h4>Nikhil Abraham</h4>
<p>

	<b>Product details </b>
	
	
<p>


			Paperback: 464 pages<br />
Publisher: Prentice Hall; 1 edition (August 11, 2008)<br />
Language: English<br />
ISBN-10: 9780132350884<br />
ISBN-13: 978-0132350884<br />
ASIN: 0132350882<br />
Product Dimensions: 7 x 1.2 x 9.2 inches<br />
Shipping Weight: 1.7 pounds 


</p>
<a href="http://localhost/index.php">Back</a>
	</div>
	
</body>
</html>