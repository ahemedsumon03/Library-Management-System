							<!-- Modal -->
<div id="myModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
<div class="modal-header" style="text-align:center;color:#fff">
Insert the following information
</div>
<div class="modal-body">
    <form class="form-horizontal" method="post" action="advance_search.php">
				<div class="control-group">
				<label class="control-label" for="inputEmail">Book Title</label>
				<div class="controls">
				<input type="text" name="title" id="inputEmail" placeholder="Enter Book Title">
				</div>
				</div>
					<div class="control-group">
					<label class="control-label" for="inputPassword">Author Name</label>
					<div class="controls">
					<input type="text" name="author" id="inputPassword" placeholder="Enter Author Name">
					</div>
					</div>		
						
    <div class="control-group">
    <div class="controls">
    <button type="submit" class="btn btn-success">Search</button>
    </div>
    </div>
    </form>
</div>
<div class="modal-footer">
<button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
</div>
</div>