<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
	<?php include('header.php'); ?>
<?php include('navbar.php'); ?>
	<div class="container" style="text-align:center;margin-top:55px;">
	
	<img src="http://localhost/images/B6.jpg" alt="" />
	<h3>The Algorithm Design Manual   <br /></h3>
	<h4> Steven S Skiena</h4>
<p>

	<b>Product details </b>
	
	
<p>


			Paperback: 76 pages <br />
Publisher: CreateSpace Independent Publishing Platform (December 7, 2017)<br />
Language: English<br />
ISBN-10: 1981497803<br />
ISBN-13: 978-1981497805<br />
Product Dimensions: 6 x 0.2 x 9 inches<br />
Shipping Weight: 4.8 ounces


</p>
<a href="http://localhost/index.php">Back</a>
	</div>
	
</body>
</html>