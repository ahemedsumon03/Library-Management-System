<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
	<?php include('header.php'); ?>
<?php include('navbar.php'); ?>
	<div class="container" style="text-align:center;margin-top:55px;">
	
	<img src="http://localhost/images/A4.jpg" alt="" />
	<h3>Photoshop CC Essentials for Photographers: Chelsea & Tony Northrup’s Video Book <br /></h3>
	<h4>Tony Northrup </h4>
<p>

	<b>Product details </b>
	
	
<p>


			File Size: 12490 KB<br />
			Publication Date: July 29, 2016<br />
			Language: English<br />
			ASIN: B01JD8Z52M<br />
			Word Wise: Not Enabled<br />
			Amazon Best Sellers Rank: #77,786 Paid in Kindle Store


</p>
<a href="http://localhost/index.php">Back</a>
	</div>
	
</body>
</html>