<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
	<?php include('header.php'); ?>
<?php include('navbar.php'); ?>
	<div class="container" style="text-align:center;margin-top:55px;">
	
	<img src="http://localhost/images/D2.jpg" alt="" />
	<h3><!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
	<?php include('header.php'); ?>
<?php include('navbar.php'); ?>
	<div class="container" style="text-align:center;margin-top:55px;">
	
	<img src="http://localhost/images/D2.jpg" alt="" />
	<h3>Indianapolis <br /></h3>
	<h4>Lynn Vincent</h4>
<p>

	<b>Product details </b>
	
	
<p>


			Paperback: 592 pages <br />
			Publisher:  Simon & Schuster; 1st Edition edition (July 10, 2018) <br />
			Language: English<br />
			ISBN-10: 1549538807<br />
			ISBN-13: 978-1549328804<br />
			Product Dimensions:  6.1 x 1.4 x 9.2 inches<br />
			Shipping Weight: 2.4 pounds ounces


</p>
<a href="http://localhost/index.php">Back</a>
	</div>
	
</body>
</html><br /></h3>
	<h4>Steven Bright</h4>
<p>

	<b>Product details </b>
	
	
<p>


			Paperback: 79 pages <br />
			Publisher: Independently published (August 18, 2017) <br />
			Language: English<br />
			ISBN-10: 1549528807<br />
			ISBN-13: 978-1549528804<br />
			Product Dimensions: 5 x 0.2 x 8 inches<br />
			Shipping Weight: 5 ounces


</p>
<a href="http://localhost/index.php">Back</a>
	</div>
	
</body>
</html>