<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
	<?php include('header.php'); ?>
<?php include('navbar.php'); ?>
	<div class="container" style="text-align:center;margin-top:55px;">
	
	<img src="http://localhost/images/A4.jpg" alt="" />
	<h3>Exposure Mastery: Aperture, Shutter Speed & ISO. The Difference Between Good and BREATHTAKING Photographs<br /></h3>
	<h4>Brian Black</h4>
<p>

	<b>Product details </b>
	
	
<p>


			File Size: 5394 KB<br />
			Publication Date: May 19, 2015 <br />
			Language: English<br />
			ASIN: B00XYDRFI0<br />
			Product Dimensions: 10.2 x 0.3 x 10.4 inches<br />
			Shipping Weight: 5 ounces<br/>


</p>
<a href="http://localhost/index.php">Back</a>
	</div>
	
</body>
</html>