<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
	<?php include('header.php'); ?>
<?php include('navbar.php'); ?>
	<div class="container" style="text-align:center;margin-top:55px;">
	
	<img src="http://localhost/images/A4.jpg" alt="" />
	<h3>Basics Of Photography: 2 in 1 Learn to Capture and Edit images (Learn Photography)<br /></h3>
	<h4>Diego Garcia </h4>
<p>

	<b>Product details </b>
	
	
<p>


			File Size: 24001 KB<br />
			Publication Date: August 29, 2018<br />
			Print Length: 31 pages <br />
			Language: English<br />
			ASIN: B07GZ6KWFG<br />
			Word Wise: Not Enabled<br />
			Amazon Best Sellers Rank: #76,368 Paid in Kindle Store


</p>
<a href="http://localhost/index.php">Back</a>
	</div>
	
</body>
</html>