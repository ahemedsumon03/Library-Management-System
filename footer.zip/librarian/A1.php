<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
	<?php include('header.php'); ?>
<?php include('navbar.php'); ?>
	<div class="container" style="text-align:center;margin-top:55px;">
	
	<img src="http://localhost/images/A1.jpg" alt="" />
	<h3>Computer Fundamentals: Introduction to Computer, Hardware, Software, Operating System, and Internet <br /></h3>
	<h4>Steven Bright</h4>
<p>

	<b>Product details </b>
	
	
<p>


			Paperback: 79 pages <br />
			Publisher: Independently published (August 18, 2017) <br />
			Language: English<br />
			ISBN-10: 1549528807<br />
			ISBN-13: 978-1549528804<br />
			Product Dimensions: 5 x 0.2 x 8 inches<br />
			Shipping Weight: 5 ounces


</p>
<a href="http://localhost/index.php">Back</a>
	</div>
	
</body>
</html>