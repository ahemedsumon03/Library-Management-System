<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
	<?php include('header.php'); ?>
<?php include('navbar.php'); ?>
	<div class="container" style="text-align:center;margin-top:55px;">
	
	<img src="http://localhost/images/A2.jpg" alt="" />
	<h3>The Art of Computer Programming <br /></h3>
	<h4>Donald E. Knuth</h4>
<p>

	<b>Product details </b>
	
	
<p>


			Hardcover: 9998 pages <br />
Publisher: Addison-Wesley Professional; 1 edition (March 3, 2011)<br />
Language: English<br />
ISBN-10: 0321751043<br />
ISBN-13: 978-0321751041<br />
Product Dimensions: 7.3 x 7 x 10.1 inches<br />
Shipping Weight: 12.9 pounds <br />


</p>
<a href="http://localhost/index.php">Back</a>
	</div>
	
</body>
</html>