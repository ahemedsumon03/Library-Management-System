<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
	<?php include('header.php'); ?>
<?php include('navbar.php'); ?>
	<div class="container" style="text-align:center;margin-top:55px;">
	
	<img src="http://localhost/images/D5.jpg" alt="" />
	<h3>DSLR Photography for Beginners: Take 10 Times Better Pictures in 48 Hours or Less! Best Way to Learn Digital Photography, Master Your DSLR Camera & Improve Your Digital SLR Photography Skills  <br /></h3>
	<h4>Brian Black </h4>
<p>

	<b>Product details </b>
	
	
<p>


			File Size: 9967 KB<br />
			Print Length: 131 pages <br />
			Publication Date: April 1, 2013<br />
			Language: English<br />
			ASIN: B00C5OUI9W<br />
			Word Wise: Not Enabled<br />
			Amazon Best Sellers Rank: #16,276 Paid in Kindle Store


</p>
<a href="http://localhost/index.php">Back</a>
	</div>
	
</body>
</html>