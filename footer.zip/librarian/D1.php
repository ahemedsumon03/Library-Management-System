<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
	<?php include('header.php'); ?>
<?php include('navbar.php'); ?>
	<div class="container" style="text-align:center;margin-top:55px;">
	
	<img src="http://localhost/images/D1.jpg" alt="" />
	<h3>Educated: A Memoir<br /></h3>
	<h4>Tara Westover</h4>
<p>

	<b>Product details </b>
	
	
<p>


			Paperback: 352 pages <br />
			Publisher: Random House; First Edition edition (February 20, 2018) <br />
			Language: English<br />
			ISBN-10: 1549528801<br />
			ISBN-13: 978-1549528814<br />
			Product Dimensions:6.3 x 1.1 x 9.5 inches <br />
			Shipping Weight: 1.2 pounds


</p>
<a href="http://localhost/index.php">Back</a>
	</div>
	
</body>
</html>