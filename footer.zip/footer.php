
    <footer class="footer">
      <div class="container">
	  <div class="foot-margin">
        <p><a>2019 Library Management System. All Rights Reserved. </a></p>
      </div>
      </div>
    </footer>
	
	<script type="text/javascript">
			$(function() {
				$('#da-thumbs > li').hoverdir();
			});
		</script>
	
<div id="logout" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
<div class="modal-body">
<div class="alert alert-danger">Are you sure you want to Logout?</div>
</div>
<div class="modal-footer">
<button class="btn" data-dismiss="modal" aria-hidden="true">Cancel</button>
<a href="logout.php" class="btn btn-danger">Ok</a>
</div>
</div>	

<script type='text/javascript' src='scripts/jquery.easing.1.3.js'></script> 
<script type='text/javascript' src='scripts/jquery.hoverIntent.minified.js'></script> 
<script type='text/javascript' src='scripts/diapo.js'></script> 
</body>
</html>