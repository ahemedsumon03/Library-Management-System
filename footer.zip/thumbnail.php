
<ul id="da-thumbs" class="da-thumbs">
					<li>
						<a href="http://localhost/A1.php">
							<img src="images/A1.jpg" />
							<div><span>Computer Fundamentals</span><span>Author: P.K.Sinha</span></div>
						</a>
					</li>
					<li>
						<a href="http://localhost/A2.php">
							<img src="images/A2.jpg" />
							<div><span>The Art of Computer Programming</span><span>Donald E. Knuth</span></div>
						</a>
					</li>
					<li>
						<a href="http://localhost/A3.php">
							<img src="images/A3.jpg" />
							<div><span>Clean Code: A Handbook of Agile Software Craftsmanship 1st Edition</span><span>Robert C. Martin</span></div>
						</a>
					</li>
					<li>
						<a href="http://localhost/A4.php">
							<img src="images/A4.jpg" />
							<div><span>Coding All-in-One For Dummies </span><span>Nikhil Abraham</span></div>
						</a>
					</li>
					<li>
						<a href="http://localhost/A5.php">
							<img src="images/A5.jpg" />
							<div><span>Computer Programming For Beginners</span><span>Cooper Alvin</span></div>
						</a>
					</li>
					<li>
						<a href="http://localhost/A6.php">
							<img src="images/A6.jpg" />
							<div><span>Beginning Programming All-In-One Desk Reference For Dummies</span><span>Cooper Alvin</span></div>
						</a>
					</li>
					
			</ul>		
	<ul id="da-thumbs" class="da-thumbs">				
					<li>
						<a href="http://localhost/B1.php">
							<img src="images/B1.jpg" />
							<div><span>Python Programming: An Introduction to Computer Science </span><span>John Zelle</span></div>

						</a>
					</li>
					<li>
						<a href="http://localhost/B2.php">
							<img src="images/B2.jpg" />
							<div><span>Computer Programming for Beginners: Fundamentals of Programming Terms and Concepts</span><span>Nathan Clark</span></div>
						</a>
					</li>
					<li>
						<a href="http://localhost/B3.php">
							<img src="images/B3.jpg" />
							<div><span>Computer Science Distilled: Learn the Art of Solving Computational Problems</span><span>Wladston Ferreira Filho</span></div>
						</a>
					</li>
					<li>
						<a href="http://localhost/B4.php">
							<img src="images/B4.jpg" />
							<div><span>Hello World!: Computer Programming for Kids and Other Beginners</span><span>Warren Sande</span></div>
						</a>
					</li>
					<li>
						<a href="http://localhost/B5.php">
							<img src="images/B5.jpg" />
							<div><span>Introduction to Algorithms, 3rd Edition </span><span>Thomas H. Cormen</span></div>
						</a>
					</li>
					<li>
						<a href="http://localhost/B6.php">
							<img src="images/B6.jpg" />
							<div><span>The Algorithm Design Manual </span><span>Steven S Skiena</span></div>
						</a>
					</li>
</ul>
				
<ul id="da-thumbs" class="da-thumbs">				
					<li>
						<a href="http://localhost/C1.php">
							<img src="images/C1.jpg" />
							<div><span>Deep Learning (Adaptive Computation and Machine Learning series) </span><span>Ian Goodfellow</span></div>
						</a>
					</li>
					<li>
						<a href="http://localhost/C2.php">
							<img src="images/C2.jpg" />
							<div><span>Machine Learning: An Algorithmic Perspective</span><span>Stephen Marsland</span></div>
						</a>
					</li>
					<li>
						<a href="http://localhost/C3.php">
							<img src="images/C3.jpg" />
							<div><span>Python Machine Learning: Machine Learning and Deep Learning with Python</span><span>Sebastian Raschka</span></div>
						</a>
					</li>
					<li>
						<a href="http://localhost/C4.php">
							<img src="images/C4.jpg" />
							<div><span>Introduction to Java Programming and Data Structures, Comprehensive Version</span><span>Y. Daniel Liang</span></div>
						</a>
					</li>
					<li>
						<a href="http://localhost/C5.php">
							<img src="images/C5.jpg" />
							<div><span>The Manga Guide to Microprocessors</span><span>Michio Shibuya</span></div>
						</a>
					</li>
					<li>
						<a href="http://localhost/C6.php">
							<img src="images/C6.jpg" />
							<div><span>Digital Logic and Microprocessor Design with Interfacing</span><span>Enoch O. Hwang</span></div>
						</a>
					</li>
</ul>
<ul id="da-thumbs" class="da-thumbs">				
					<li>
						<a href="http://localhost/D1.php">
							<img src="images/D1.jpg" />
							<div><span>Educated: A Memoir</span><span>Author: Tara Westover</span></div>
						</a>
					</li>
					<li>
						<a href="http://localhost/D2.php">
							<img src="images/D2.jpg" />
							<div><span>Indianapolis</span><span>Author:Lynn Vincent</span></div>
						</a>
					</li>
					<li>
						<a href="http://localhost/D3.php">
							<img src="images/D3.jpg" />
							<div><span>Exposure Mastery: Aperture, Shutter Speed & ISO. The Difference Between Good and BREATHTAKING Photographs</span><span>Author: Brian Black</span></div>
						</a>
					</li>
					<li>
						<a href="http://localhost/D4.php">
							<img src="images/D4.jpg" />
							<div><span>Photoshop CC Essentials for Photographers: Chelsea & Tony Northrupâ€™s Video Book</span><span>Author: Tony Northrup</span></div>
						</a>
					</li>
					<li>
						<a href="http://localhost/D5.php">
							<img src="images/D5.jpg" />
							<div><span>DSLR Photography for Beginners: Take 10 Times Better Pictures in 48 Hours or Less! Best Way to Learn Digital Photography, Master Your DSLR Camera & Improve Your Digital SLR Photography Skills</span><span>Author: Brian Black</span></div>
						</a>
					</li>
					<li>
						<a href="http://localhost/D6.php">
							<img src="images/D6.jpg" />
							<div><span>Basics Of Photography: 2 in 1 Learn to Capture and Edit images (Learn Photography)</span><span>Author: Diego Garcia</span></div>
						</a>
					</li>
</ul>				